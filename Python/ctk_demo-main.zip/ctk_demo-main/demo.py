from frontend import App

if __name__ == "__main__":
    app = App()
    app.mainloop()